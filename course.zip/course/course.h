/**
 * @file course.h
 * @author Ujjwal Raj 
 * @brief CS1XC3
 * @version 0.1
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
 /**
  * @brief Struct type with the name , code , total students 
  * 
  */
typedef struct _course 
{
  char name[100];/**< name of the student in string >**/
  char code[10];/**< code of the student in string >**/
  Student *students;/**< List of the students >**/
  int total_students;/**< list of the total number of strings >**/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


