/**
 * @file main.c
 * @mainpage main.c
 * @author Ujjwal Raj 
 * @brief main.c file CS1XC3
 * @version 0.1
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  // the function strcpy is used in order to store the name and code of the Math course that is being offered .
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  // The for loop is used to generate the students it is going to iterate till i reaches 20 ,so 0-19 times 
  //that is 20 times .
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);
//It prints out the student who topped the course . 
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);
//It prints out the number of students passing the course . 
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  // The for loop is used in order to print the students who are passing the course . 
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}