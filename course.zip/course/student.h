 
 /**
  * @brief the struct with the fields having first name , last name , student id , grades 
  * 
  */
typedef struct _student 
{ 
  char first_name[50];/**< First name of the student in string >**/
  char last_name[50];/**< Last name of the student in string >**/
  char id[11];/**< Id of the student in string >**/
  double *grades; /**< grades of the student in string >**/
  int num_grades; /**< num_grades of the student in int >**/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
